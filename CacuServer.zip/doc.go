// CacuServer project doc.go

/*
CacuServer document
*/
package main
